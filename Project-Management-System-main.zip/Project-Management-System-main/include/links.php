<script src="https://kit.fontawesome.com/5099b17d5e.js" crossorigin="anonymous"></script>
<script src="https://smtpjs.com/v3/smtp.js"></script>